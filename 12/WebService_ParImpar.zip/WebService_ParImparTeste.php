<HTML>
    <HEAD>
        <TITLE>WebService: Consumindo</TITLE>
    </HEAD>
    <BODY>
        
<?php

    $numero = 20;
    
    $xml = simplexml_load_file("http://localhost/WebService_ParImparService.php?numero=" . $numero);

    if(isset($xml->informacao))
    {
        if($xml->informacao == "PAR")
        {
            echo "O número é par.";
        }
        else if($xml->informacao == "ÍMPAR")
        {
            echo "O número é ímpar.";
        }
        else
        {
            echo "Retorno inválido.";
        }
    }
    else
    {
        echo "Falha na comunicação com o web service.";
    }
    
?>
        
    </BODY>
</HTML>