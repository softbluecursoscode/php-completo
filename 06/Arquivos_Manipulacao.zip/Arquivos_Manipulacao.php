<HTML>
    <HEAD>
        <TITLE>Manipulação de Arquivos</TITLE>
    </HEAD>
    <BODY>
        
<?php

    $filepath = "C:/Temp/teste.txt";
    
    /*
    if(is_file($filepath))
    {
        echo "O arquivo existe!<BR>";
    }
    else
    {
        echo "O arquivo não existe!<BR>";
    }
    
    $meuArquivo = fopen($filepath, "a+");
    fwrite($meuArquivo, "Softblue");
    fwrite($meuArquivo, " - Cursos online");
    fwrite($meuArquivo, "\r\n");
    fclose($meuArquivo);
    
    if(is_file($filepath))
    {
        echo "O arquivo existe!<BR>";
    }
    else
    {
        echo "O arquivo não existe!<BR>";
    }
    */
    
    $meuArquivo = fopen($filepath, "r");
    
    $buffer = fread($meuArquivo, 10);
    echo $buffer . "<BR>";
    
    $buffer = fread($meuArquivo, 10);
    echo $buffer . "<BR>";
    
    $buffer = fread($meuArquivo, 10);
    echo $buffer . "<BR>";
    
    fclose($meuArquivo);
    
    echo "<BR><BR>";
    
    $meuArquivo = fopen($filepath, "r");
    $buffer = fread($meuArquivo, filesize($filepath));
    echo utf8_encode($buffer) . "<BR>";
    fclose($meuArquivo);
    
    echo "<BR><BR>";
    
    $meuArray = file($filepath);
    foreach($meuArray as $elemento)
    {
        echo "Linha do arquivo: " . utf8_encode($elemento) . "<BR>";
    }
    // Quando aberto via file não há a naecessidade de fclose
    
    $dir = opendir("C:/");
    echo readdir($dir) . "<BR>";
    echo readdir($dir) . "<BR>";
    echo readdir($dir) . "<BR>";
    echo readdir($dir) . "<BR>";
    echo readdir($dir) . "<BR>";
    closedir($dir);

?>
        
    </BODY>
</HTML>