<?php

    $texto = "Olá usuário!<BR>";
    echo $texto;

?>