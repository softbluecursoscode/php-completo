<HTML>
    <HEAD>
        <TITLE>Formulários Simples: Tratamento</TITLE>
    </HEAD>
    <BODY>
        
<?php

    echo "Nome informado: " . $_POST["nome"] . "<BR>";
    echo "Sobrenome informado: " . $_POST["sobrenome"] . "<BR>";
    echo "Estado civil informado: " . $_POST["estadocivil"] . "<BR>";

?>
        
    </BODY>
</HTML>