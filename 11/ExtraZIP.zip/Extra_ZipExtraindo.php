<HTML>
    <HEAD>
        <TITLE>Zip: Extraindo</TITLE>
    </HEAD>
    <BODY>
        
<?php

    $filename = "Extra_ZipExemplo.zip";
    
    $meuZip = new ZipArchive();
    
    if($meuZip->open($filename) === TRUE)
    {
        $meuZip->extractTo("./Extra_ZipExtracted/");
        $meuZip->close();
        echo "Arquivos descompactados com sucesso!";
    }
    else
    {
        echo "Falha na abertura do arquivo!";
    }

?>

    </BODY>
</HTML>