<HTML>
    <HEAD>
        <TITLE>Zip: Propriedades</TITLE>
    </HEAD>
    <BODY>
        
<?php

    $filename = "Extra_ZipExemplo.zip";
    
    $meuZip = zip_open($filename);
    
    if($meuZip)
    {
        while($zipEntry = zip_read($meuZip))
        {
            echo "Nome: " . zip_entry_name($zipEntry);
            echo "<BR>Tamanho: " . zip_entry_filesize($zipEntry);
            echo "<BR>Tamanho comprimido: " . zip_entry_compressedsize($zipEntry);
            echo "<BR>Método de compressão: " . zip_entry_compressionmethod($zipEntry);
            echo "<BR><BR>";
        }
    }
    else
    {
        echo "Falha na abertura do arquivo zip.";   
    }
    
?>

    </BODY>
</HTML>