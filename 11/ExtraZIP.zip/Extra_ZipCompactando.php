<HTML>
    <HEAD>
        <TITLE>Zip: Compactando</TITLE>
    </HEAD>
    <BODY>
        
<?php

    $meuZip = new ZipArchive();
    $filename = "Extra_ZipExemplo.zip";
    
    if($meuZip->open($filename, ZIPARCHIVE::CREATE) !== TRUE)
    {
        echo "Falha na abertura e/ou criação do arquivo ".$filename;
    }
    else
    {
        // Compactando um arquivo
        $meuZip->addFile("Extra_ZipArquivoExemplo.txt");
        
        // Criar um arquivo diretamente dentro do arquivo zip
        $meuZip->addFromString("Teste.txt", "Conteúdo de teste.txt");
        $meuZip->addEmptyDir("Diretorio");
        $meuZip->addFromString("Diretorio/Teste2.txt", "Conteúdo 2");
        
        $meuZip->close();
        
        echo "Arquivo zip gerado com sucesso!";
    }
    
?>
        
    </BODY>
</HTML>